import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "张静｜内容运营 / 短视频运营",
  description: "张静的求职简历网站：5 年法律垂类内容运营与获客转化经验，专注内容策划、账号增长和咨询承接。",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
