const achievements = [
  { value: "5 年", label: "专业内容与短视频运营" },
  { value: "230 万+", label: "累计运营账号粉丝" },
  { value: "6.5 亿+", label: "内容累计播放量" },
  { value: "月均 1000+", label: "线索" },
];

const strengths = [
  { title: "把专业内容做成增长结果", copy: "从账号定位、用户分析、选题策划、脚本创作、内容发布到数据复盘，独立完成内容增长闭环。" },
  { title: "把内容流量转化为业务线索", copy: "不仅关注播放量和粉丝增长，也负责咨询承接、需求判断、线索筛选、律师匹配、分单和付费转化。" },
  { title: "把复杂内容转成用户听得懂的表达", copy: "长期服务律师、检察院和法律科技平台，擅长把法律和专业议题转化为通俗、清晰、有传播力的内容。" },
];

const capabilities = [
  { title: "内容策略", items: ["账号定位", "用户画像", "选题规划", "内容栏目搭建"] },
  { title: "短视频运营", items: ["抖音", "快手", "视频号", "小红书", "今日头条"] },
  { title: "业务转化", items: ["咨询承接", "私信沟通", "线索筛选", "加微引导", "律师匹配、分单"] },
  { title: "数据分析", items: ["播放量", "完播率", "互动率", "涨粉率", "私信率、有效客资率"] },
  { title: "项目管理", items: ["内容排期", "脚本管理", "拍摄协作", "发布流程", "复盘机制"] },
];

const experiences = [
  { date: "2025.04 — 至今", company: "北京律品汇科技有限公司", role: "内容运营", intro: "法律科技内容运营机构，为签约律师提供新媒体运营与获客服务。", bullets: ["主导 3 个小红书法律账号运营，负责账号定位、选题策划、脚本撰写、内容发布和数据复盘，2 篇内容阅读量突破 10 万。", "通过法律问题型内容和用户需求承接，月均促成新增付费咨询 100+ 单，单笔咨询价格 49.9 元。", "负责微信公众号、美团渠道的一线咨询，包括私信与来电沟通、用户需求判断、加微引导、律师匹配和线索分单；公众号高峰期日均咨询 10+ 条。", "从 0 到 1 搭建律所美团商户账号，负责商户内容、咨询承接和 GEO 内容优化。", "公众号工伤主题精准内容单篇阅读量达到 1 万+。"] },
  { date: "2024.03 — 2025.03", company: "成都市青白江区人民检察院", role: "宣传策划", intro: "围绕检察与普法议题，负责线上线下公众传播内容。", bullets: ["负责微信公众号、微博、普法短视频、漫画、文章及节点专题的策划与执行。", "将法律和检察专业内容转化为通俗易懂的公众传播内容，覆盖线上和线下宣传渠道。", "编剧作品获得川渝法治微视频大赛一等奖，策划漫画获得第五届四川互联网辟谣优秀作品奖。", "作品曾被《检察日报》等媒体刊登或转载。"] },
  { date: "2023.03 — 2024.01", company: "成都华律网络服务有限公司", role: "短视频运营", intro: "法律咨询业务的新媒体矩阵与直播业务运营。", bullets: ["负责抖音、快手、视频号、今日头条等平台的法律账号矩阵运营。", "从 0 到 1 搭建法律直播业务，参与直播选题、内容策划、账号运营和线索承接。", "每月产出短视频 120 条，月均筛选有效客资 1600+ 条，推动月均成交额约 20 万元。", "建立内容生产和数据复盘机制，根据播放、完播、互动、私信和客资数据持续优化选题。"] },
  { date: "2021.07 — 2023.02", company: "北京即明律师事务所", role: "短视频内容运营", intro: "征地拆迁类律师 IP 内容增长与线索转化。", bullets: ["主导征地拆迁类律师 IP 的账号定位、内容选题、脚本策划和视觉呈现。", "负责账号流量、粉丝增长和咨询线索转化，对内容效果进行周期性复盘。", "围绕用户高频问题建立选题库和内容生产机制，持续提升账号内容的传播效率和用户咨询意愿。"] },
];

const projects = [
  { title: "征地拆迁马丹凤律师", label: "律师 IP 孵化", background: "从 0 开始打造征地拆迁领域律师 IP，目标是提升账号影响力并持续获取精准咨询线索。", responsibility: "负责账号定位、选题策划、脚本创作、内容呈现、发布节奏和数据复盘。", method: "围绕征地拆迁用户的高频问题，建立案例解读、政策解释、风险提醒三类内容栏目；根据播放率、互动率、涨粉率和咨询情况持续调整选题方向。", results: ["全网粉丝 140 万+", "运营期全渠道增粉 55 万", "年度总播放量 4.5 亿", "累计产出百万播放视频 84 条", "累计产出十万播放视频 154 条", "千万播放视频 11 条", "抖音从 0 起步突破 30 万粉丝", "单月最高增粉 10 万"] },
  { title: "征地拆迁向娟律师", label: "账号增长实验", background: "通过快速测试账号定位和内容模型，寻找高反馈、高增长的内容方向。", responsibility: "负责选题测试、内容策划、数据分析和高反馈内容的复用。", method: "对不同类型的选题、表达方式和视频结构进行快速测试，将表现较好的内容沉淀为可复制的生产方法。", results: ["全网粉丝 80 万+", "快手单月增粉 10 万", "抖音单月突破 1 万粉丝", "单月播放量 3000 万+"] },
  { title: "星耀刑事团", label: "多平台内容矩阵", background: "围绕刑事法律咨询业务，搭建多平台内容矩阵，提升品牌曝光和有效线索获取。", responsibility: "负责文案、拍摄协作、内容发布、账号维护和数据复盘。", method: "根据抖音、快手、视频号等平台的内容特征调整选题和表达方式，并结合直播进行内容与线索承接。", results: ["刑事法律 IP 全网粉丝突破 10 万", "月播放量 1000 万+", "实现短视频内容与直播业务协同", "持续获取法律咨询线索"] },
];

export default function Home() {
  return <>
    <header className="topbar"><div className="shell nav-inner"><a className="brand" href="#top" aria-label="回到首页"><span className="brand-avatar">张</span><span><strong>张静</strong><small>内容增长 · 短视频运营</small></span></a><nav aria-label="主导航"><a href="#overview">个人优势</a><a href="#capabilities">运营能力</a><a href="#experience">工作经历</a><a href="#projects">项目成果</a><a href="#contact">联系我</a></nav></div></header>
    <main id="top">
      <section className="hero shell"><div className="hero-main"><p className="eyebrow">CONTENT GROWTH / SHORT VIDEO OPERATIONS</p><h1>内容增长<br /><em>与短视频运营</em></h1><p className="hero-summary">5年专业内容与短视频运营经验，长期深耕法律内容赛道，累计运营账号粉丝230万+、内容播放量6.5亿+。擅长账号孵化、选题策划、短视频内容生产、直播协同、线索转化与数据复盘。</p><div className="hero-tags">{["账号孵化", "短视频策划", "内容增长", "直播运营", "线索转化", "私域承接", "数据复盘", "专业内容转译"].map(tag => <span key={tag}>{tag}</span>)}</div><div className="job-facts"><span><b>目标岗位</b>内容运营 / 短视频运营 / 内容增长</span><span><b>工作城市</b>成都</span><span><b>工作年限</b>5年</span><span><b>联系邮箱</b>1968532942@qq.com</span></div><div className="hero-actions"><a className="primary-button" href="/zhangjing-resume.pdf" download>下载 PDF 简历 <span>↓</span></a><a className="secondary-link" href="#projects">查看代表作品 <span>→</span></a></div><div className="hero-achievements" aria-label="核心成果">{achievements.map(item => <div className="hero-achievement" key={item.label}><strong>{item.value}</strong><span>{item.label}</span></div>)}</div></div></section>

      <section id="overview" className="section shell"><div className="section-meta"><span>01</span><small>VALUE</small></div><div className="section-content"><div className="section-title"><p className="eyebrow">个人优势</p><h2>内容增长之外，<br /><em>更关注业务结果。</em></h2><p className="section-intro">法律内容经验是一套可迁移的方法：理解专业信息、建立内容模型，再把流量接到真实的业务需求。</p></div><div className="strength-grid">{strengths.map((item, index) => <article className="strength" key={item.title}><span>0{index + 1}</span><h3>{item.title}</h3><p>{item.copy}</p></article>)}</div></div></section>
      <section id="capabilities" className="section shell"><div className="section-meta"><span>02</span><small>CAPABILITIES</small></div><div className="section-content"><div className="section-title split-title"><div><p className="eyebrow">运营能力</p><h2>从内容生产到<br /><em>业务承接的完整链路。</em></h2></div><p className="section-intro">可迁移至教育、消费、知识服务、ToB 服务与其他专业服务行业。</p></div><div className="capability-grid">{capabilities.map((item, index) => <article className="capability" key={item.title}><span>0{index + 1}</span><h3>{item.title}</h3><p>{item.items.join(" · ")}</p></article>)}</div></div></section>
      <section id="experience" className="section shell"><div className="section-meta"><span>03</span><small>EXPERIENCE</small></div><div className="section-content"><div className="section-title split-title"><div><p className="eyebrow">工作履历</p><h2>内容、增长与<br /><em>转化的一线经验。</em></h2></div><p className="section-intro">每段经历均围绕内容动作、运营方法与可验证结果呈现。</p></div><div className="timeline">{experiences.map(item => <article className="timeline-item" key={item.company}><time>{item.date}</time><div className="timeline-body"><div className="job-heading"><h3>{item.company}</h3><span>{item.role}</span></div><p className="job-summary">{item.intro}</p><ul>{item.bullets.map(bullet => <li key={bullet}>{bullet}</li>)}</ul></div></article>)}</div></div></section>
      <section id="projects" className="section shell"><div className="section-meta"><span>04</span><small>PROJECTS</small></div><div className="section-content"><div className="section-title split-title"><div><p className="eyebrow">代表项目</p><h2>项目结果背后，<br /><em>是可复用的运营方法。</em></h2></div><p className="section-intro">用项目背景、具体职责、运营方法和结果数据说明个人贡献。</p></div><div className="project-cards">{projects.map((item, index) => <article className="project-card" key={item.title}><div className="project-top"><span>0{index + 1} / {item.label}</span><span className="work-disabled">查看作品 · 材料待补充</span></div><h3>{item.title}</h3><dl><div><dt>项目背景</dt><dd>{item.background}</dd></div><div><dt>我的职责</dt><dd>{item.responsibility}</dd></div><div><dt>运营方法</dt><dd>{item.method}</dd></div></dl><div className="result-block"><span>项目结果</span><ul>{item.results.map(result => <li key={result}>{result}</li>)}</ul></div></article>)}</div><p className="materials-note">作品按钮暂不跳转：待补充代表视频、账号主页或脱敏数据截图后，再连接真实作品材料。</p></div></section>
      <section className="section shell background-section"><div className="section-meta"><span>05</span><small>BACKGROUND</small></div><div className="section-content background-grid"><div><p className="eyebrow">教育背景</p><h2>广告学 × 新闻学</h2><div className="education-row"><time>2017—2021</time><div><strong>南京邮电大学</strong><span>广告学 · 本科（双一流）</span></div></div><div className="education-row"><time>2019—2020</time><div><strong>南京师范大学</strong><span>新闻学 · 交换生（211）</span></div></div></div><div className="honors"><p className="eyebrow">内容荣誉</p><ul><li>川渝法治微视频大赛一等奖</li><li>四川互联网辟谣优秀作品奖</li><li>作品曾被《检察日报》等媒体刊登或转载</li></ul></div></div></section>
      <section id="contact" className="contact shell"><div><p className="eyebrow">06 / CONTACT</p><h2>期待加入一个<br /><em>把内容做成结果的团队。</em></h2><p>目标岗位：内容运营 / 短视频运营 / 内容增长 / 账号运营 / 内容营销 / 运营负责人 · 成都</p></div><div className="contact-card"><span>EMAIL</span><a href="mailto:1968532942@qq.com">1968532942@qq.com <b>↗</b></a><a className="resume-link" href="/zhangjing-resume.pdf" download>下载 PDF 简历 <b>↓</b></a><small>电话与微信可在沟通后提供</small></div></section>
    </main><footer><div className="shell"><span>© 2026 张静</span><span>CONTENT GROWTH &amp; SHORT VIDEO OPERATIONS</span></div></footer>
  </>;
}
